library(shiny)
library(ggplot2)
library(plotly)
library(bslib)
library(dplyr)

paliwo <- read.csv("paliwo.csv")

zmienne_paliwo <-c("Railcar"="carrail","Locomotive"="locomotive")
zmienna_paliwo_2 <- c("Electricity"="electricity","Diesel"="diesel")

ui <- fluidPage(
  HTML('<style>
       .checkbox-inline {
         margin-left: 10px;
       }
       </style
       '),
  
  titlePanel(""),
  textOutput('text'),
  
  fluidRow(
    column(6, 
           selectInput('kraj_paliwo',
                       "Choose a country:",
                       choices = unique(paliwo$TIME), 
                       selected = "Poland",
                       multiple =T),
           selectInput('zmienna_paliwo',
                       "Choose a type of vehicle:",
                       zmienne_paliwo)
           
    ),
    column(6,
           selectInput('zmienna2_paliwo',
                       "Choose a type of motor energy:",
                       zmienna_paliwo_2),
           sliderInput('rok_paliwo',
                       "Choose a date range:", 
                       value=c(min(as.numeric(paliwo$year)),max(as.numeric(paliwo$year))),
                       min=min(as.numeric(paliwo$year)),
                       max=max(as.numeric(paliwo$year)),
                       step=1,
                       sep = ""))
    
  ),
  fluidRow(
    column(12,
           plotlyOutput("barPlot")
    ),
    
  ),
  
  
)


server <- function(input, output) {
  
  ### PALIWO JULKA ###################################################################################
  output$barPlot <- renderPlotly({
    plot_ly(
      paliwo%>%filter(paliwo$TIME %in% input$kraj_paliwo,
                  paliwo$year>=input$rok_paliwo[1],
                  paliwo$year<=input$rok_paliwo[2])%>% 
        select(TIME,year,n = paste(input$zmienna2_paliwo,input$zmienna_paliwo, sep ="_")), 
      x= ~year,
      y= ~n,
      color = ~TIME,
      type = "bar") %>%
      layout(title='Number of machines based on its type and energy',
             xaxis = list(title = 'Year'),
             yaxis = list(title = 'Number of machines'))
    
  })
  ###################################################################################################
  
}


shinyApp(ui = ui, server = server)

