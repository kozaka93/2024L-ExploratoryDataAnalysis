library(shiny)
library(ggplot2)
library(plotly)
library(bslib)
library(dplyr)
library(leaflet)
library(shinythemes)


# do wypadkow
wypadki <- read.csv("wypadki.csv")
zmienne_wypadki <-c("Total" = "total","Passenger" = "passengers",
                    "Employee"="employee","Level crossing user" = "lvlcrossingusers",
                    "Unauthorised"="unauthorised","Unknown"="unknown")

# do paliwa
paliwo <- read.csv("paliwo.csv")
zmienne_paliwo <-c("Railcar"="carrail","Locomotive"="locomotive")
zmienna_paliwo_2 <- c("Electricity"="electricity","Diesel"="diesel")

# do map
secs_to_hours <- function(secs) {
  hours = secs %/% 3600
  mins = (secs - hours * 3600) %/% 60
  hours = ifelse(nchar(as.character(hours)) < 2, paste0("0", as.character(hours)),
                 as.character(hours))
  mins = ifelse(nchar(as.character(mins)) < 2, paste0("0", as.character(mins)),
                as.character(mins))
  paste(hours, mins, sep = ":")
}
stops <- read.delim("pkpic/stops.txt", sep = ",")



ui <- fluidPage(
  theme = shinytheme("flatly"),
  tags$style(HTML("
    body {
      background-color: #2F4F4F; 
    }
  ")),
  navbarPage("TRANSPORT",
             tabPanel("Railways in Poland",
                      fluidPage(
                        
                        fluidRow(
                          column(6, 
                                 wellPanel(
                                 h3(textOutput("text1")),
                                 fluidRow(
                                 column(6,
                                   selectInput("station",
                                               "Choose the starting station:",
                                               unique(stops$stop_name))),
                                 column(6,
                                   selectInput("statistics",
                                               "Choose preferred statistics:",
                                               c("Minimal time" = "min_time", 
                                                 "Average time" = "mean_time")))
                                 ))
                          ),
                          column(6, 
                                 wellPanel(
                                 h3(textOutput("text2")),
                                 fluidRow(
                                   column(6,
                                     selectInput("station1",
                                                 "Choose the starting station:",
                                                 unique(stops$stop_name))),
                                   column(6,
                                 uiOutput("station2")))
                                 )
                          )
                        ),
                        
                        fluidRow(
                          column(6, 
                                 leafletOutput("map1")
                          ),
                          column(6, 
                                 leafletOutput("map2")
                          )
                        )
                        
                      )),
             tabPanel("Accidents and fuel",
                      
                      fluidPage(
                        tags$style(HTML("
                          .well {
                            margin-bottom: 7px; /* Ustawienie marginesu poniżej wellPanel */
                          }
                        ")),
                        wellPanel(
                          fluidRow(
                            column(3, 
                                   selectInput('zmienna_wypadki',
                                               "Choose a category of a person:",
                                               zmienne_wypadki),
                                   sliderInput('rok_wypadki',
                                               "Choose a date range:", 
                                               value=c(min(as.numeric(wypadki$year)),max(as.numeric(wypadki$year))),
                                               min=min(as.numeric(wypadki$year)),
                                               max=max(as.numeric(wypadki$year)),
                                               step=1,
                                               sep = "")
                            ),
                                   
                            column(4,
                                   plotlyOutput("pointPlot", width = "420px", height = "258px")
                            ),
                            column(2,
                                   selectInput('kraj_wypadki',
                                               "Choose a country:",
                                               choices = unique(wypadki$TIME), 
                                               selected = "Poland",
                                               multiple =T),
                            ),
                            column(3,
                                   wellPanel(
                                     style = "border: 1px solid #000000;",
                                     h4("Railway accidents"),
                                     p("Railway accidents in Europe have seen a declining trend over the past decade, reflecting improved safety measures and infrastructure maintenance.
                                       However, persistent challenges remain in ensuring comprehensive rail safety standards across the continent."),
                                   ),
                                   )
                            
                          )
                        ), ####################################################################### 
                        wellPanel(
                          fluidRow(
                            column(3, 
                                   selectInput('zmienna_paliwo',
                                               "Choose a type of vehicle:",
                                               zmienne_paliwo),
                                   selectInput('zmienna2_paliwo',
                                               "Choose a type of motor energy:",
                                               zmienna_paliwo_2),
                                   sliderInput('rok_paliwo',
                                               "Choose a date range:", 
                                               value=c(min(as.numeric(paliwo$year)),max(as.numeric(paliwo$year))),
                                               min=min(as.numeric(paliwo$year)),
                                               max=max(as.numeric(paliwo$year)),
                                               step=1,
                                               sep = "")
                            ),
                          
                          column(4,
                                 plotlyOutput("barPlot", width = "420px", height = "258px")
                          ),
                          column(2,
                                 selectInput('kraj_paliwo',
                                             "Choose a country:",
                                             choices = unique(paliwo$TIME), 
                                             selected = "Poland",
                                             multiple =T)
                          ),
                          column(3,
                            wellPanel(
                              style = "border: 1px solid #000000;",
                              h4("Fuel"),
                              p("Fuels used for trains in Europe reflect a dynamic landscape, 
                                with a shift towards cleaner energy sources such as electric power gaining momentum. Despite advancements in eco-friendly alternatives, traditional fuels like diesel still persist due to economic considerations.")
                            ),
                          )
                          
                          
                        ))
                      )
             )           
))


server <- function(input, output) {
  ### WYPADKI - JULKA ###############################################################################
  output$pointPlot <- renderPlotly({
    plot_ly(
      wypadki%>%filter(wypadki$TIME %in% input$kraj_wypadki,
                       wypadki$year>=input$rok_wypadki[1],
                       wypadki$year<=input$rok_wypadki[2])%>% select(TIME,year,n = input$zmienna_wypadki), 
      x= ~year,
      y= ~n,
      color=~TIME,
      colors='Set1',
      type = "scatter",
      mode = 'lines+markers',
      line = list(width = 1))%>%
      layout(title='Number of people killed in railway accidents',
             xaxis = list(title = 'Year'),
             yaxis = list(title = 'Number of people killed')) 
    
  })
  ####################################################################################################
  
  ### PALIWO JULKA ###################################################################################
  output$barPlot <- renderPlotly({
    plot_ly(
      paliwo%>%filter(paliwo$TIME %in% input$kraj_paliwo,
                      paliwo$year>=input$rok_paliwo[1],
                      paliwo$year<=input$rok_paliwo[2])%>% 
        select(TIME,year,n = paste(input$zmienna2_paliwo,input$zmienna_paliwo, sep ="_")), 
      x= ~year,
      y= ~n,
      color = ~TIME,
      type = "bar") %>%
      layout(title='Number of machines based on type and energy',
             xaxis = list(title = 'Year'),
             yaxis = list(title = 'Number of machines'))
    
  })
  ###################################################################################################
  
  ### WSZYSTKO CO Z MAPAMI OLA ######################################################################
  
  output$text1 <- renderText({"How long does a train journey take?"})
  
  output$text2 <- renderText({"What is the fastest route from station A to 
      station B?"})
  
  output$map1 <- renderLeaflet({
    file <- paste0("data/", gsub(" ", "_", input$station))
    req_station <- readRDS(file)
    
    req_station <- req_station %>% 
      group_by(stop_name) %>% 
      mutate(min_time = min(min_time), mean_time = mean(mean_time))
    
    statistics <- as.vector(t(req_station[, input$statistics]))
    
    pal <- colorNumeric(
      palette = c("darkgreen", "yellow", "red"),
      domain = statistics)
    
    leaflet(req_station) %>% 
      addTiles() %>% 
      addCircleMarkers(radius = 5, opacity = 1, fillOpacity = 1, 
                       lng = ~stop_lon, lat = ~stop_lat, 
                       color = ~pal(statistics), 
                       popup = paste0("Station: ", req_station$stop_name,
                                      "<br>Time: ", 
                                      secs_to_hours(statistics)))
    
  }) %>% bindCache(input$station, input$statistics)
  
  output$station2 <- renderUI({
    file <- paste0("data/", gsub(" ", "_", input$station1))
    req_station <- readRDS(file)
    
    selectInput("station2", "Choose the destination:", 
                unique(req_station$stop_name))  
  })
  
  output$map2 <- renderLeaflet({
    file <- paste0("data/", gsub(" ", "_", input$station1))
    req_station <- readRDS(file)
    
    trips <- req_station %>% 
      filter(stop_name %in% input$station2) %>% 
      filter(min_time == suppressWarnings(min(min_time)))
    
    trip_names <- trips$trip_short_name
    col <- palette.colors(palette = "Set2")[1:length(trip_names)]
    length(trip_names) <- length(col)
    
    pal <- data.frame(trip = trip_names, col = col)
    
    map <- leaflet(req_station) 
    
    for (trip in trips$trip_short_name) {
      trip_time <- req_station %>% 
        filter(trip_short_name == trip & stop_name %in% input$station2) %>% 
        pull(min_time)
      
      route <- req_station %>% 
        filter(trip_short_name == trip & min_time <= trip_time) %>% 
        arrange(min_time)
      
      map <- map %>% 
        addTiles() %>% 
        addCircleMarkers(data = route, radius = 5, opacity = 1, fillOpacity = 1, 
                         lng = ~stop_lon, lat = ~stop_lat, 
                         color = pal[pal$trip == trip, "col"], 
                         popup = paste0("Station: ", route$stop_name,
                                        "<br>Time: ",
                                        secs_to_hours(route$min_time))) %>% 
        addPolylines(data = route, opacity = 1, lng = ~stop_lon, lat = ~stop_lat, 
                     color = pal[pal$trip == trip, "col"])
    }
    
    map
    
  }) %>% bindCache(input$station1, input$station2)
}
###################################################################################################


shinyApp(ui = ui, server = server)
