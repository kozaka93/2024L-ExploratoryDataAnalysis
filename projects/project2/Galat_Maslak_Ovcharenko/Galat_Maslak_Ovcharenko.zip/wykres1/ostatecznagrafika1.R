library(shiny)
library(ggplot2)
library(plotly)
library(bslib)
library(dplyr)

wypadki <- read.csv("wypadki.csv")

zmienne_wypadki <-c("Total" = "total","Passenger" = "passengers",
           "Employee"="employee","Level crossing user" = "lvlcrossingusers",
           "Unauthorised"="unauthorised","Unknown"="unknown")

ui <- fluidPage(
  HTML('<style>
       .checkbox-inline {
         margin-left: 10px;
       }
       </style
       '),
  
  titlePanel(""),
  textOutput('text'),
  
  fluidRow(
    column(6, 
           selectInput('kraj_wypadki',
                       "Choose a country:",
                       choices = unique(wypadki$TIME), 
                       selected = "Poland",
                       multiple =T),
           sliderInput('rok_wypadki',
                       "Choose a date range:", 
                       value=c(min(as.numeric(wypadki$year)),max(as.numeric(wypadki$year))),
                       min=min(as.numeric(wypadki$year)),
                       max=max(as.numeric(wypadki$year)),
                       step=1,
                       sep = "")
           
    ),
    column(6,
           selectInput('zmienna_wypadki',
                       "Choose a category of a person:",
                       zmienne_wypadki))
    
  ),
  fluidRow(
    column(12,
           plotlyOutput("pointPlot")
    ),
    
  ),
  
  
)

server <- function(input, output) {

  ### WYPADKI - JULKA ######################################################################
  output$pointPlot <- renderPlotly({
    plot_ly(
      wypadki%>%filter(wypadki$TIME %in% input$kraj_wypadki,
                      wypadki$year>=input$rok_wypadki[1],
                      wypadki$year<=input$rok_wypadki[2])%>% select(TIME,year,n = input$zmienna_wypadki), 
      x= ~year,
      y= ~n,
      color=~TIME,
      colors='Set1',
      type = "scatter",
      mode = 'lines+markers',
      line = list(width = 1))%>%
      layout(title='Number of people killed in railway accidents',
             xaxis = list(title = 'Year'),
             yaxis = list(title = 'Number of people killed')) 
    
  })
  #########################################################################################

  
}


shinyApp(ui = ui, server = server)


